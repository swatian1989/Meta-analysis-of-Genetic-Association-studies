# Meta-analysis (R + Python)

A small, **GitHub-ready** meta-analysis project that runs the **same odds-ratio meta-analysis workflow** in **Python** and **R**:

- Random-effects pooled estimate (OR)
- Heterogeneity: Q, I², τ²
- Publication bias: funnel plot + Egger/linreg test
- Influence diagnostics: Baujat plot + leave-one-out
- Publication-ready PNG figures + a results text report

## Folder structure

```text
meta-analysis/
├─ data/
│  ├─ template_or_ci.csv
│  ├─ template_or_ci_string.csv
│  └─ template_effectsize.csv
├─ scripts/
│  ├─ meta_analysis.py
│  └─ meta_analysis.R
├─ outputs/                 # auto-created outputs go here
├─ docs/
│  ├─ QUICKSTART.md
│  ├─ META_ANALYSIS_PYTHON.md
│  └─ META_ANALYSIS_R.md
├─ requirements.txt
└─ LICENSE
```

## Quickstart

### Python

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt

python scripts/meta_analysis.py --input data/template_or_ci.csv --output-dir outputs
```

### R

```r
install.packages(c('optparse','dplyr','readr','janitor','meta','metafor','ggplot2'))
```

```bash
Rscript scripts/meta_analysis.R --input data/template_or_ci.csv --outdir outputs
```

## Input formats supported

The scripts accept any of the following (column names are flexible / case-insensitive):

1) **Effect size already computed**
- `logOR` + `SE`

2) **OR with CI bounds**
- `OR` + `CI_Lower` + `CI_Upper`

3) **R only: OR with CI in one string column**
- `OR` + a column like `x95_percent_ci` containing strings like `1.20-1.80` or `1.20–1.80`

See `data/` templates and the docs in `docs/`.
