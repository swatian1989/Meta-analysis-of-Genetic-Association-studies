# Quickstart

## Python

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python scripts/meta_analysis.py --input data/template_or_ci.csv --output-dir outputs
```

## R

```r
# Install packages once
install.packages(c('optparse','dplyr','readr','janitor','meta','metafor','ggplot2'))

# Run
system('Rscript scripts/meta_analysis.R --input data/template_or_ci.csv --outdir outputs')
```

Outputs will appear in `outputs/`.
